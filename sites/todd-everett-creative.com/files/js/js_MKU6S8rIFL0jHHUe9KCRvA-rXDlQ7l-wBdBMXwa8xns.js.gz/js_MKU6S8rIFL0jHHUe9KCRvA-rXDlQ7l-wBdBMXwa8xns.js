/*
(function ($) {
 //...
})(jQuery);
*/;
